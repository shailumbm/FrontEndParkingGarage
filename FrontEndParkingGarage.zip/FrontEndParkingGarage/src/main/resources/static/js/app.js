let currentUser = JSON.parse(localStorage.getItem('currentUser')) || null;
let users = JSON.parse(localStorage.getItem('users')) || [];
let vehicles = JSON.parse(localStorage.getItem('vehicles')) || [];
let parkingSpots = JSON.parse(localStorage.getItem('parkingSpots')) || [];

function toggleAuth() {
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    if (loginForm.style.display === 'none') {
        loginForm.style.display = 'block';
        registerForm.style.display = 'none';
    } else {
        loginForm.style.display = 'none';
        registerForm.style.display = 'block';
    }
}

function register() {
    const firstName = document.getElementById('reg-firstname').value;
    const lastName = document.getElementById('reg-lastname').value;
    const email = document.getElementById('reg-email').value;
    const password = document.getElementById('reg-password').value;

    if (!firstName || !lastName || !email || !password) {
        alert('All fields are required');
        return;
    }

    if (password.length < 8) {
        alert('Password must be at least 8 characters');
        return;
    }

    if (!email.includes('@')) {
        alert('Please enter a valid email');
        return;
    }

    if (users.find(u => u.email === email)) {
        alert('User already exists');
        return;
    }

    users.push({ firstName, lastName, email, password });
    localStorage.setItem('users', JSON.stringify(users));
    alert('Registration successful! Please login.');
    toggleAuth();
}

function login() {
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    const user = users.find(u => u.email === email && u.password === password);
    if (user) {
        currentUser = user;
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        initApp();
    } else {
        alert('Invalid email or password');
    }
}

function logout() {
    currentUser = null;
    localStorage.removeItem('currentUser');
    initApp();
}

function initApp() {
    if (currentUser) {
        document.getElementById('auth-section').style.display = 'none';
        document.getElementById('navbar').style.display = 'block';
        document.getElementById('main-content').style.display = 'block';
        showSection('home');
    } else {
        document.getElementById('auth-section').style.display = 'block';
        document.getElementById('navbar').style.display = 'none';
        document.getElementById('main-content').style.display = 'none';
    }
}

function showSection(sectionId) {
    const sections = ['home-section', 'register-car-section', 'park-vehicle-section', 'registered-cars-section'];
    sections.forEach(s => document.getElementById(s).style.display = 'none');
    document.getElementById(sectionId + '-section').style.display = 'block';

    if (sectionId === 'home') updateHome();
    if (sectionId === 'registered-cars') updateRegisteredCars();
    if (sectionId === 'park-vehicle') updateParkVehicleDropdown();
}

function updateHome() {
    const userVehicles = vehicles.filter(v => v.ownerEmail === currentUser.email);
    const homeMessage = document.getElementById('home-message');
    const parkedList = document.getElementById('parked-cars-list');
    
    homeMessage.innerHTML = `Welcome, ${currentUser.firstName}!`;
    
    if (userVehicles.length === 0) {
        homeMessage.innerHTML += '<p>You have no cars registered. Please <a href="#" onclick="showSection(\'register-car\')">register a new car</a>.</p>';
    }

    const userParked = parkingSpots.filter(ps => userVehicles.some(v => v.plate === ps.plate));
    if (userParked.length > 0) {
        parkedList.innerHTML = '<h3>Your Parked Vehicles:</h3><ul>' + 
            userParked.map(ps => `<li>${ps.plate} is at Floor ${ps.floor}, Spot ${ps.spot}</li>`).join('') + 
            '</ul>';
    } else {
        parkedList.innerHTML = '';
    }
}

function registerCar() {
    const make = document.getElementById('car-make').value;
    const plate = document.getElementById('car-plate').value;
    const color = document.getElementById('car-color').value;

    if (!make || !plate || !color) {
        alert('All fields are required');
        return;
    }

    if (!/^[a-zA-Z0-9]{7}$/.test(plate)) {
        alert('License plate must be 7 alphanumeric characters');
        return;
    }

    if (vehicles.find(v => v.plate === plate)) {
        alert('Vehicle with this plate is already registered');
        return;
    }

    vehicles.push({ make, plate, color, ownerEmail: currentUser.email });
    localStorage.setItem('vehicles', JSON.stringify(vehicles));
    alert('Vehicle registered successfully!');
    showSection('registered-cars');
}

function updateRegisteredCars() {
    const userVehicles = vehicles.filter(v => v.ownerEmail === currentUser.email);
    const tbody = document.getElementById('cars-list-body');
    tbody.innerHTML = userVehicles.map(v => `
        <tr>
            <td>${v.make}</td>
            <td>${v.plate}</td>
            <td>${v.color}</td>
            <td><button class="delete-btn" onclick="deleteVehicle('${v.plate}')">Delete</button></td>
        </tr>
    `).join('');
}

function deleteVehicle(plate) {
    if (confirm('Are you sure you want to delete this vehicle? It will also be removed from any parking spot.')) {
        vehicles = vehicles.filter(v => v.plate !== plate);
        parkingSpots = parkingSpots.filter(ps => ps.plate !== plate);
        localStorage.setItem('vehicles', JSON.stringify(vehicles));
        localStorage.setItem('parkingSpots', JSON.stringify(parkingSpots));
        updateRegisteredCars();
    }
}

function updateParkVehicleDropdown() {
    const userVehicles = vehicles.filter(v => v.ownerEmail === currentUser.email);
    const select = document.getElementById('park-car-select');
    select.innerHTML = '<option value="">Select Registered Vehicle</option>' + 
        userVehicles.map(v => `<option value="${v.plate}">${v.make} - ${v.plate}</option>`).join('');
}

function parkVehicle() {
    const floor = document.getElementById('park-floor').value;
    const spot = document.getElementById('park-spot').value;
    const plate = document.getElementById('park-car-select').value;

    if (!floor || !spot || !plate) {
        alert('All fields are required');
        return;
    }

    if (spot < 1 || spot > 100) {
        alert('Spot number must be between 1 and 100');
        return;
    }

    if (parkingSpots.find(ps => ps.floor === floor && ps.spot === spot)) {
        alert('This spot is already occupied');
        return;
    }

    if (parkingSpots.find(ps => ps.plate === plate)) {
        alert('This vehicle is already parked');
        return;
    }

    parkingSpots.push({ floor, spot, plate });
    localStorage.setItem('parkingSpots', JSON.stringify(parkingSpots));
    alert('Vehicle parked successfully!');
    showSection('home');
}

// Initialize on load
initApp();
